package com.snowarden.stickduel;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.*;
import java.net.*;
public class MainActivity extends Activity {
  private WebView web; private volatile Socket socket; private volatile ServerSocket server;
  private volatile BufferedReader reader; private volatile PrintWriter writer; private volatile String netStatus="LAN offline";
  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    web=new WebView(this); web.setBackgroundColor(0xFF070D1C);
    WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
    web.addJavascriptInterface(new LanBridge(),"AndroidLAN"); web.setWebViewClient(new WebViewClient());
    setContentView(web); web.loadUrl("file:///android_asset/index.html");
  }
  private void setup(Socket s)throws Exception { socket=s; reader=new BufferedReader(new InputStreamReader(s.getInputStream())); writer=new PrintWriter(new OutputStreamWriter(s.getOutputStream()),true); netStatus="LAN connected: "+s.getInetAddress().getHostAddress(); new Thread(()->{try{String line;while((line=reader.readLine())!=null){final String msg=line;runOnUiThread(()->web.evaluateJavascript("window.__lanMessage("+org.json.JSONObject.quote(msg)+")",null));}}catch(Exception e){netStatus="LAN disconnected";}}).start(); }
  public class LanBridge {
    @JavascriptInterface public String host(int port) { new Thread(()->{try{server=new ServerSocket(port);netStatus="LAN host ready on port "+port+"; waiting for player";Socket s=server.accept();setup(s);}catch(Exception e){netStatus="LAN host error: "+e.getMessage();}}).start(); try{return "Hosting LAN on port "+port+". Share your Wi-Fi IP with Player 2.";}catch(Exception e){return "Host error";}}
    @JavascriptInterface public String connect(String ip,int port) {new Thread(()->{try{Socket s=new Socket();s.connect(new InetSocketAddress(ip,port),6000);setup(s);}catch(Exception e){netStatus="LAN connection failed: "+e.getMessage();}}).start();return "Connecting to "+ip+"...";}
    @JavascriptInterface public void send(String message) {try{if(writer!=null)writer.println(message);}catch(Exception e){netStatus="LAN send failed";}}
    @JavascriptInterface public String poll(){return "";}
    @JavascriptInterface public String status(){return netStatus;}
  }
  @Override protected void onDestroy(){try{if(socket!=null)socket.close();if(server!=null)server.close();}catch(Exception e){}super.onDestroy();}
}
