# Stick Duel — AndroidForge-ready project

**Game:** Stick Duel  
**Package:** `com.snowarden.stickduel`  
**Type:** Offline 2-player local stickman arena game for Android (same phone, landscape).

## Features in this starter build
- Two-player touch controls on one screen
- Blaster, shotgun spread, and arcane magic projectiles
- Health bars, jumping, platforms, hit effects, rematch and pause
- Classic Duel and Magic Mayhem modes
- Game banner and launcher icon assets
- Runs offline; no permissions or network access needed

## Controls
- Player 1: left-side buttons
- Player 2: right-side buttons
- WEAPON: cycle blaster → shotgun → arcane staff
- ⚡: fire / cast
- Keyboard testing: P1 A/D/W, F fire, G weapon; P2 arrows, / fire, . weapon

## Build
Open this folder in Android Studio and build an APK, or upload this Android project ZIP to your AndroidForge build workflow. The APK has not been built or device-tested in this generated project.
