# Stick Duel v3 — AndroidForge-ready project

A landscape Android 2D stick-fighter starter project with same-phone twin analog controls, character color choices, multiple arena layouts, magic and projectile combat, a settings panel, and a basic TCP LAN bridge.

## Performance
- No external game engine or network dependencies.
- Simple Canvas 2D rendering; low-effects option limits particles and grid rendering.
- Android WebView wrapper, landscape orientation, no audio/media assets required.
- Settings include graphics quality, particle toggle, background glow, FPS display, control size/opacity, dead zone, gameplay tuning, colors, and audio toggles.

## Build
Open this project in Android Studio or upload the ZIP to AndroidForge. This is a generated source project; it has not been compiled or tested on real devices. LAN play requires testing on two phones on the same Wi-Fi and may need networking refinements for reliable synchronized gameplay.
