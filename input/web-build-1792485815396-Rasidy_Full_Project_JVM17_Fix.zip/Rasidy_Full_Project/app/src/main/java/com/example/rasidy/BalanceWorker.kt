package com.example.rasidy

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class BalanceWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("rasidy", Context.MODE_PRIVATE)
        // DEMO ONLY: manually entered value, not the real 1xBet balance.
        val balance = prefs.getFloat("balance", 0f)
        val sent = prefs.getBoolean("alert_sent", false)

        if (balance >= 90f && !sent) {
            BalanceNotifications.show(
                applicationContext,
                "رصيدي: تحقق من الرصيد",
                "الرصيد التجريبي وصل إلى $balance جنيه. افتح 1xBet وتأكد من الرصيد بنفسك."
            )
            prefs.edit().putBoolean("alert_sent", true).apply()
        }
        return Result.success()
    }
}
