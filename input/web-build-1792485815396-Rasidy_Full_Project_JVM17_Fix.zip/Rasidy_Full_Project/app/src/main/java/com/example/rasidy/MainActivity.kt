package com.example.rasidy

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("rasidy", Context.MODE_PRIVATE) }
    private val navy = Color.rgb(8, 25, 54)
    private val green = Color.rgb(0, 190, 120)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermission()
        scheduleWorker()

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(28, 34, 28, 24)
            setBackgroundColor(navy)
        }

        val title = TextView(this).apply {
            text = "👛 رصيدي"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "تابع هدفك — 90 جنيه"
            textSize = 17f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        val warning = TextView(this).apply {
            text = "نسخة تجريبية: التطبيق لا يتصل بحساب 1xBet ولا يقرأ رصيدًا حقيقيًا. أدخل قيمة تجريبية لاختبار التنبيهات."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
        }
        val amount = EditText(this).apply {
            hint = "الرصيد التجريبي بالجنيه"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setSingleLine(true)
            setText(prefs.getFloat("balance", 0f).toString())
        }
        val save = Button(this).apply {
            text = "حفظ الرصيد التجريبي"
            setOnClickListener {
                val value = amount.text.toString().toFloatOrNull()
                if (value == null || value < 0f) {
                    warning.text = "من فضلك اكتب رقمًا صحيحًا."
                } else {
                    prefs.edit().putFloat("balance", value).putBoolean("alert_sent", false).apply()
                    warning.text = if (value >= 90f) {
                        "الرصيد التجريبي وصل إلى الهدف. اضغط «اختبار الإشعار»."
                    } else {
                        "تم حفظ الرصيد التجريبي. المتبقي للهدف: ${"%.2f".format(90f - value)} جنيه."
                    }
                }
            }
        }
        val test = Button(this).apply {
            text = "اختبار الإشعار"
            setOnClickListener {
                val value = prefs.getFloat("balance", 0f).toDouble()
                if (value >= 90.0) {
                    BalanceNotifications.show(
                        this@MainActivity,
                        "رصيدي: تحقق من الرصيد",
                        "القيمة التجريبية وصلت إلى $value جنيه. افتح 1xBet وتحقق بنفسك."
                    )
                    prefs.edit().putBoolean("alert_sent", true).apply()
                    warning.text = "تم إرسال إشعار تجريبي. لا توجد معاملة مالية."
                } else {
                    warning.text = "أدخل قيمة 90 جنيه أو أكثر لاختبار الإشعار."
                }
            }
        }
        val openSite = Button(this).apply {
            text = "فتح موقع 1xBet"
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://1xbet.com/")))
                } catch (_: Exception) {
                    warning.text = "تعذر فتح الموقع. افتحه من المتصفح يدويًا."
                }
            }
        }
        val status = TextView(this).apply {
            text = "حالة المراقبة: تجريبية\nالفحص الخلفي: كل 15 دقيقة تقريبًا (قد يتأخر حسب أندرويد)."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, 18, 0, 0)
        }

        listOf<View>(title, subtitle, warning, amount, save, test, openSite, status).forEach {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = 10
            page.addView(it, lp)
        }
        setContentView(page)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "balance_alerts", "تنبيهات الرصيد", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "تنبيهات هدف الرصيد التجريبي" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun scheduleWorker() {
        val request = PeriodicWorkRequestBuilder<BalanceWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "rasidy_balance_check", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}
